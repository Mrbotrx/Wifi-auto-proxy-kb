package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences

class AppSettings(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("kb_pro_tv_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_FAVORITES = "key_favorites"
        private const val KEY_LAST_CHANNEL_ID = "key_last_channel_id"
        private const val KEY_AUDIO_TRACK = "key_audio_track"
        private const val KEY_OLED_MODE = "key_oled_mode"
        private const val KEY_BUFFER_SIZE = "key_buffer_size"
        private const val KEY_CUSTOM_M3U = "key_custom_m3u"
        private const val KEY_HW_ACCELERATION = "key_hw_acceleration"
    }

    fun getFavorites(): Set<String> {
        return prefs.getStringSet(KEY_FAVORITES, emptySet()) ?: emptySet()
    }

    fun toggleFavorite(channelId: String): Boolean {
        val current = getFavorites().toMutableSet()
        val isNowFav = if (current.contains(channelId)) {
            current.remove(channelId)
            false
        } else {
            current.add(channelId)
            true
        }
        prefs.edit().putStringSet(KEY_FAVORITES, current).apply()
        return isNowFav
    }

    var lastChannelId: String?
        get() = prefs.getString(KEY_LAST_CHANNEL_ID, null)
        set(value) = prefs.edit().putString(KEY_LAST_CHANNEL_ID, value).apply()

    var isOledMode: Boolean
        get() = prefs.getBoolean(KEY_OLED_MODE, false)
        set(value) = prefs.edit().putBoolean(KEY_OLED_MODE, value).apply()

    var bufferSizeMs: Int
        get() = prefs.getInt(KEY_BUFFER_SIZE, 3000)
        set(value) = prefs.edit().putInt(KEY_BUFFER_SIZE, value).apply()

    var customM3uUrl: String?
        get() = prefs.getString(KEY_CUSTOM_M3U, null)
        set(value) = prefs.edit().putString(KEY_CUSTOM_M3U, value).apply()

    var isHwAcceleration: Boolean
        get() = prefs.getBoolean(KEY_HW_ACCELERATION, true)
        set(value) = prefs.edit().putBoolean(KEY_HW_ACCELERATION, value).apply()
}
