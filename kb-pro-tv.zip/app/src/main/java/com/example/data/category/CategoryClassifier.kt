package com.example.data.category

object CategoryClassifier {

    const val CATEGORY_ALL = "All"
    const val CATEGORY_BANGLA = "Bangla"
    const val CATEGORY_NEWS = "News"
    const val CATEGORY_SPORTS = "Sports"
    const val CATEGORY_ENTERTAINMENT = "Entertainment"
    const val CATEGORY_MOVIES = "Movies"
    const val CATEGORY_MUSIC = "Music"
    const val CATEGORY_KIDS = "Kids"
    const val CATEGORY_DOCUMENTARY = "Documentary"
    const val CATEGORY_INTERNATIONAL = "International"
    const val CATEGORY_OTHER = "Other"

    val ORDERED_CATEGORIES = listOf(
        CATEGORY_ALL,
        CATEGORY_BANGLA,
        CATEGORY_NEWS,
        CATEGORY_SPORTS,
        CATEGORY_ENTERTAINMENT,
        CATEGORY_MOVIES,
        CATEGORY_MUSIC,
        CATEGORY_KIDS,
        CATEGORY_DOCUMENTARY,
        CATEGORY_INTERNATIONAL,
        CATEGORY_OTHER
    )

    private val EXCLUDED_CATEGORIES = listOf(
        "religion", "islamic", "hindu", "christian", "spiritual", "peace tv", "makkah", "madina"
    )

    fun isExcluded(text: String): Boolean {
        val lower = text.lowercase()
        return EXCLUDED_CATEGORIES.any { lower.contains(it) }
    }

    fun classify(groupTitle: String, channelName: String): String {
        val combined = "$groupTitle $channelName".lowercase()

        if (isExcluded(combined)) {
            return CATEGORY_OTHER
        }

        // Bengali detection (Unicode range U+0980 to U+09FF)
        val hasBengaliChar = channelName.any { it in '\u0980'..'\u09FF' } ||
                groupTitle.any { it in '\u0980'..'\u09FF' }
        if (hasBengaliChar || combined.contains("bangla") || combined.contains("bd") ||
            combined.contains("dhaka") || combined.contains("somoy") || combined.contains("jamuna") ||
            combined.contains("ekattor") || combined.contains("nagorik") || combined.contains("atn") ||
            combined.contains("channel i") || combined.contains("ntv") || combined.contains("r tv") ||
            combined.contains("desh tv") || combined.contains("boishakhi") || combined.contains("deepto") ||
            combined.contains("gazi tv") || combined.contains("maasranga")
        ) {
            return CATEGORY_BANGLA
        }

        if (combined.contains("news") || combined.contains("khobor") || combined.contains("cnn") ||
            combined.contains("bbc") || combined.contains("al jazeera") || combined.contains("reuters")
        ) {
            return CATEGORY_NEWS
        }

        if (combined.contains("sport") || combined.contains("cricket") || combined.contains("football") ||
            combined.contains("t sports") || combined.contains("willow") || combined.contains("star sports") ||
            combined.contains("sony ten") || combined.contains("super sport")
        ) {
            return CATEGORY_SPORTS
        }

        if (combined.contains("movie") || combined.contains("cinema") || combined.contains("film") ||
            combined.contains("hbo") || combined.contains("star gold") || combined.contains("sony max")
        ) {
            return CATEGORY_MOVIES
        }

        if (combined.contains("music") || combined.contains("song") || combined.contains("gaan") ||
            combined.contains("mtv") || combined.contains("b4u music")
        ) {
            return CATEGORY_MUSIC
        }

        if (combined.contains("kid") || combined.contains("cartoon") || combined.contains("pogo") ||
            combined.contains("disney") || combined.contains("nickelodeon") || combined.contains("sonic")
        ) {
            return CATEGORY_KIDS
        }

        if (combined.contains("doc") || combined.contains("discovery") || combined.contains("nat geo") ||
            combined.contains("history") || combined.contains("animal planet") || combined.contains("wild")
        ) {
            return CATEGORY_DOCUMENTARY
        }

        if (combined.contains("entertain") || combined.contains("drama") || combined.contains("serial") ||
            combined.contains("zee") || combined.contains("star plus") || combined.contains("colors")
        ) {
            return CATEGORY_ENTERTAINMENT
        }

        if (combined.contains("international") || combined.contains("world") || combined.contains("usa") ||
            combined.contains("uk")
        ) {
            return CATEGORY_INTERNATIONAL
        }

        return CATEGORY_OTHER
    }
}
