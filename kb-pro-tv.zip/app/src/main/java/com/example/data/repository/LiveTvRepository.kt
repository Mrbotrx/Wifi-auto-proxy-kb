package com.example.data.repository

import android.content.Context
import com.example.data.cache.PlaylistCacheManager
import com.example.data.model.Channel
import com.example.data.parser.M3uParser
import com.example.data.preferences.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class LiveTvRepository(private val context: Context) {

    val appSettings = AppSettings(context)
    private val cacheManager = PlaylistCacheManager(context)

    companion object {
        const val PRIMARY_PLAYLIST_URL = "https://raw.githubusercontent.com/Mrbotrx/BDXI_KB/main/playlists/BDXI.m3u"
        const val BACKUP_PLAYLIST_URL = "https://raw.githubusercontent.com/Mrbotrx/BDXI_KB/main/playlists/BDXI.m3u"
    }

    suspend fun getChannels(forceRefresh: Boolean = false): Result<List<Channel>> = withContext(Dispatchers.IO) {
        val favoriteIds = appSettings.getFavorites()

        if (!forceRefresh) {
            val cachedContent = cacheManager.loadPlaylist()
            if (cachedContent != null) {
                val parsed = M3uParser.parse(cachedContent).map {
                    it.copy(isFavorite = favoriteIds.contains(it.id))
                }
                if (parsed.isNotEmpty()) {
                    return@withContext Result.success(parsed)
                }
            }
        }

        // Fetch online
        val targetUrl = appSettings.customM3uUrl?.takeIf { it.isNotBlank() } ?: PRIMARY_PLAYLIST_URL
        try {
            val content = downloadUrl(targetUrl)
            cacheManager.savePlaylist(content)
            val parsed = M3uParser.parse(content).map {
                it.copy(isFavorite = favoriteIds.contains(it.id))
            }
            Result.success(parsed)
        } catch (e: Exception) {
            // Try backup or cache fallback
            val cachedContent = cacheManager.loadPlaylist()
            if (cachedContent != null) {
                val parsed = M3uParser.parse(cachedContent).map {
                    it.copy(isFavorite = favoriteIds.contains(it.id))
                }
                Result.success(parsed)
            } else {
                Result.failure(e)
            }
        }
    }

    private fun downloadUrl(urlStr: String): String {
        val url = URL(urlStr)
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 12000
        conn.readTimeout = 15000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "KB-PRO-TV-Android/1.0")

        return conn.inputStream.bufferedReader().use { it.readText() }
    }
}
