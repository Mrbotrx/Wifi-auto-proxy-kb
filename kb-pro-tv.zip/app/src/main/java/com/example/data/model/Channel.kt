package com.example.data.model

data class Channel(
    val id: String,
    val name: String,
    val logoUrl: String,
    val streamUrl: String,
    val category: String,
    val originalGroup: String = "",
    val language: String = "Bangla",
    val isFavorite: Boolean = false
) {
    val maskedStreamUrl: String
        get() {
            if (streamUrl.length <= 15) return "http://***"
            val prefix = streamUrl.take(12)
            val suffix = streamUrl.takeLast(6)
            return "$prefix...$suffix"
        }
}
