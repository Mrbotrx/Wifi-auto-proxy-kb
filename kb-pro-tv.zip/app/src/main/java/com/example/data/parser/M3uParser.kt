package com.example.data.parser

import com.example.data.category.CategoryClassifier
import com.example.data.model.Channel
import java.util.UUID

object M3uParser {

    private val GROUP_REGEX = Regex("""group-title="([^"]*)"""", RegexOption.IGNORE_CASE)
    private val LOGO_REGEX = Regex("""tvg-logo="([^"]*)"""", RegexOption.IGNORE_CASE)
    private val ID_REGEX = Regex("""tvg-id="([^"]*)"""", RegexOption.IGNORE_CASE)
    private val NAME_REGEX = Regex("""tvg-name="([^"]*)"""", RegexOption.IGNORE_CASE)

    fun parse(content: String): List<Channel> {
        val channels = mutableListOf<Channel>()
        val lines = content.lines()
        var currentInfo = ""

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isEmpty()) continue

            if (trimmed.startsWith("#EXTINF:", ignoreCase = true)) {
                currentInfo = trimmed
            } else if (!trimmed.startsWith("#") && currentInfo.isNotEmpty()) {
                val streamUrl = trimmed
                val groupTitle = GROUP_REGEX.find(currentInfo)?.groupValues?.get(1) ?: ""
                val logoUrl = LOGO_REGEX.find(currentInfo)?.groupValues?.get(1) ?: ""
                val tvgId = ID_REGEX.find(currentInfo)?.groupValues?.get(1) ?: ""
                val tvgName = NAME_REGEX.find(currentInfo)?.groupValues?.get(1) ?: ""

                // Extract channel display name after comma
                val commaIndex = currentInfo.lastIndexOf(',')
                val displayName = if (commaIndex != -1 && commaIndex < currentInfo.length - 1) {
                    currentInfo.substring(commaIndex + 1).trim()
                } else if (tvgName.isNotEmpty()) {
                    tvgName
                } else {
                    "Channel ${channels.size + 1}"
                }

                // Filter out excluded categories like religious channels as required
                if (!CategoryClassifier.isExcluded(groupTitle) && !CategoryClassifier.isExcluded(displayName)) {
                    val category = CategoryClassifier.classify(groupTitle, displayName)
                    val id = if (tvgId.isNotEmpty()) tvgId else UUID.nameUUIDFromBytes(streamUrl.toByteArray()).toString()

                    channels.add(
                        Channel(
                            id = id,
                            name = displayName,
                            logoUrl = logoUrl,
                            streamUrl = streamUrl,
                            category = category,
                            originalGroup = groupTitle
                        )
                    )
                }
                currentInfo = ""
            }
        }
        return channels
    }
}
