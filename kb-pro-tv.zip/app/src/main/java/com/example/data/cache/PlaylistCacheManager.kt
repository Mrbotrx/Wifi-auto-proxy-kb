package com.example.data.cache

import android.content.Context
import java.io.File

class PlaylistCacheManager(private val context: Context) {

    private val cacheFile: File
        get() = File(context.cacheDir, "cached_playlist.m3u")

    fun savePlaylist(content: String) {
        try {
            cacheFile.writeText(content)
        } catch (_: Exception) {}
    }

    fun loadPlaylist(): String? {
        return try {
            if (cacheFile.exists() && cacheFile.length() > 0) {
                cacheFile.readText()
            } else null
        } catch (_: Exception) {
            null
        }
    }
}
