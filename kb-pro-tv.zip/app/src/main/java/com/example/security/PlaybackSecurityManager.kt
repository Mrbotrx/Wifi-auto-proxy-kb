package com.example.security

import android.content.Context
import android.os.Build
import android.util.Log
import com.example.BuildConfig
import java.security.MessageDigest
import java.util.UUID

sealed class PlaybackAuthorizationResult {
    data class Authorized(
        val playbackUri: String,
        val sessionToken: String,
        val expiresAt: Long
    ) : PlaybackAuthorizationResult()

    data class Denied(
        val reason: String
    ) : PlaybackAuthorizationResult()
}

class PlaybackSecurityManager(private val context: Context) {

    private val deviceFingerprint: String by lazy {
        generateDeviceFingerprint()
    }

    private var currentSessionToken: String? = null
    private var sessionExpiresAt: Long = 0L
    private val requestTimestamps = ArrayDeque<Long>()

    // Concurrency tracking
    private var activePlaybackChannelId: String? = null

    // Rate limiting parameters: max 30 playback authorizations per 60 seconds
    private val maxRequestsPerWindow = 30
    private val windowDurationMillis = 60_000L

    init {
        initializeSession()
    }

    private fun initializeSession() {
        // Create initial short-lived session (valid for 1 hour)
        val nonce = UUID.randomUUID().toString()
        val raw = "$deviceFingerprint:$nonce:${System.currentTimeMillis()}"
        currentSessionToken = sha256(raw).take(32)
        sessionExpiresAt = System.currentTimeMillis() + (60 * 60 * 1000L)
    }

    /**
     * Authorizes a stream for playback through session validation,
     * rate-limiting, and concurrent session tracking.
     */
    @Synchronized
    fun authorizePlayback(channelId: String, streamUrl: String): PlaybackAuthorizationResult {
        val now = System.currentTimeMillis()

        // 1. Anti-abuse: Rate limit check
        cleanOldRequests(now)
        if (requestTimestamps.size >= maxRequestsPerWindow) {
            safeLogWarn("SecurityManager", "Rate limit exceeded for playback authorization")
            return PlaybackAuthorizationResult.Denied("Request rate limit exceeded. Please wait a moment.")
        }
        requestTimestamps.addLast(now)

        // 2. Validate / Refresh session if expired
        if (currentSessionToken == null || now >= sessionExpiresAt) {
            initializeSession()
        }

        val token = currentSessionToken
            ?: return PlaybackAuthorizationResult.Denied("Session initialization failed")

        // 3. Concurrency check & single playback binding
        activePlaybackChannelId = channelId

        // 4. Return authorized playback result with session binding
        return PlaybackAuthorizationResult.Authorized(
            playbackUri = streamUrl,
            sessionToken = token,
            expiresAt = sessionExpiresAt
        )
    }

    @Synchronized
    fun releasePlayback(channelId: String) {
        if (activePlaybackChannelId == channelId) {
            activePlaybackChannelId = null
        }
    }

    /**
     * Sanitizes/masks stream URLs for safe UI display and logging.
     * Prevents revealing underlying tokens, auth headers, or raw stream URLs.
     */
    fun maskStreamUrl(url: String): String {
        return try {
            val uri = android.net.Uri.parse(url)
            val host = uri.host ?: "stream"
            val scheme = uri.scheme ?: "https"
            "$scheme://$host/*** [Protected Stream]"
        } catch (e: Exception) {
            "Protected Live Stream"
        }
    }

    private fun cleanOldRequests(currentTime: Long) {
        val cutoff = currentTime - windowDurationMillis
        while (requestTimestamps.isNotEmpty() && requestTimestamps.first() < cutoff) {
            requestTimestamps.removeFirst()
        }
    }

    private fun generateDeviceFingerprint(): String {
        val raw = "${Build.BRAND}-${Build.MODEL}-${Build.MANUFACTURER}-${Build.DEVICE}"
        return sha256(raw).take(16)
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    companion object {
        fun safeLogInfo(tag: String, message: String) {
            if (BuildConfig.DEBUG) {
                Log.i(tag, message)
            }
        }

        fun safeLogWarn(tag: String, message: String) {
            if (BuildConfig.DEBUG) {
                Log.w(tag, message)
            }
        }

        fun safeLogError(tag: String, message: String, throwable: Throwable? = null) {
            if (BuildConfig.DEBUG) {
                Log.e(tag, message, throwable)
            }
        }
    }
}
