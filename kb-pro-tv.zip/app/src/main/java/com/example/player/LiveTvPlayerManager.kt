package com.example.player

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import com.example.data.model.Channel
import com.example.security.PlaybackAuthorizationResult
import com.example.security.PlaybackSecurityManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class VideoTrackInfo(
    val index: Int,
    val label: String,
    val width: Int,
    val height: Int,
    val bitrate: Int
)

data class AudioTrackInfo(
    val index: Int,
    val label: String,
    val language: String?
)

@OptIn(UnstableApi::class)
class LiveTvPlayerManager(
    private val context: Context,
    private val securityManager: PlaybackSecurityManager = PlaybackSecurityManager(context)
) {

    private val trackSelector: DefaultTrackSelector = DefaultTrackSelector(context).apply {
        setParameters(buildUponParameters().setPreferredVideoMimeType("video/avc"))
    }

    private var exoPlayer: ExoPlayer? = null

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isBuffering = MutableStateFlow(false)
    val isBuffering: StateFlow<Boolean> = _isBuffering.asStateFlow()

    private val _playbackError = MutableStateFlow<String?>(null)
    val playbackError: StateFlow<String?> = _playbackError.asStateFlow()

    private val _currentChannel = MutableStateFlow<Channel?>(null)
    val currentChannel: StateFlow<Channel?> = _currentChannel.asStateFlow()

    private val _availableVideoTracks = MutableStateFlow<List<VideoTrackInfo>>(emptyList())
    val availableVideoTracks: StateFlow<List<VideoTrackInfo>> = _availableVideoTracks.asStateFlow()

    private val _availableAudioTracks = MutableStateFlow<List<AudioTrackInfo>>(emptyList())
    val availableAudioTracks: StateFlow<List<AudioTrackInfo>> = _availableAudioTracks.asStateFlow()

    private val _selectedVideoTrackIndex = MutableStateFlow(-1) // -1 is Auto
    val selectedVideoTrackIndex: StateFlow<Int> = _selectedVideoTrackIndex.asStateFlow()

    private val _selectedAudioTrackIndex = MutableStateFlow(-1)
    val selectedAudioTrackIndex: StateFlow<Int> = _selectedAudioTrackIndex.asStateFlow()

    private var retryCount = 0
    private val maxRetries = 2
    private var retryJob: Job? = null
    private val coroutineScope = CoroutineScope(Dispatchers.Main)

    init {
        initPlayer()
    }

    private fun initPlayer() {
        if (exoPlayer != null) return

        val renderersFactory = DefaultRenderersFactory(context).apply {
            setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            setEnableDecoderFallback(true)
        }

        exoPlayer = ExoPlayer.Builder(context, renderersFactory)
            .setTrackSelector(trackSelector)
            .build()
            .apply {
                playWhenReady = true
                addListener(playerListener)
            }
    }

    val player: ExoPlayer
        get() {
            if (exoPlayer == null) initPlayer()
            return exoPlayer!!
        }

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            when (state) {
                Player.STATE_BUFFERING -> {
                    _isBuffering.value = true
                    _playbackError.value = null
                }
                Player.STATE_READY -> {
                    _isBuffering.value = false
                    _playbackError.value = null
                    retryCount = 0
                }
                Player.STATE_ENDED -> {
                    _isBuffering.value = false
                }
                Player.STATE_IDLE -> {
                    _isBuffering.value = false
                }
            }
        }

        override fun onIsPlayingChanged(isPlayingState: Boolean) {
            _isPlaying.value = isPlayingState
        }

        override fun onTracksChanged(tracks: Tracks) {
            extractAvailableTracks(tracks)
        }

        override fun onPlayerError(error: PlaybackException) {
            _isBuffering.value = false
            _isPlaying.value = false
            PlaybackSecurityManager.safeLogError("LiveTvPlayer", "Player error: ${error.errorCodeName}")

            if (retryCount < maxRetries) {
                retryCount++
                retryJob?.cancel()
                retryJob = coroutineScope.launch {
                    delay(1500L * retryCount)
                    _currentChannel.value?.let { ch ->
                        playChannel(ch, isRetry = true)
                    }
                }
            } else {
                _playbackError.value = "Stream temporarily unavailable."
            }
        }
    }

    fun playChannel(channel: Channel, isRetry: Boolean = false) {
        if (!isRetry) {
            retryCount = 0
            retryJob?.cancel()
        }

        val authResult = securityManager.authorizePlayback(channel.id, channel.streamUrl)
        if (authResult is PlaybackAuthorizationResult.Denied) {
            _playbackError.value = authResult.reason
            return
        }

        val playbackUri = (authResult as PlaybackAuthorizationResult.Authorized).playbackUri

        _currentChannel.value = channel
        _playbackError.value = null
        _isBuffering.value = true

        val p = player
        p.stop()
        p.clearMediaItems()

        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10000)
            .setReadTimeoutMs(15000)
            .setUserAgent("KB-PRO-TV-Player/1.0")

        val dataSourceFactory = DefaultDataSource.Factory(context, httpDataSourceFactory)

        val mediaSource = HlsMediaSource.Factory(dataSourceFactory)
            .setAllowChunklessPreparation(true)
            .createMediaSource(MediaItem.fromUri(Uri.parse(playbackUri)))

        p.setMediaSource(mediaSource)
        p.prepare()
        p.playWhenReady = true
    }

    fun togglePlayPause() {
        exoPlayer?.let {
            if (it.isPlaying) {
                it.pause()
            } else {
                it.play()
            }
        }
    }

    fun retryPlayback() {
        _currentChannel.value?.let {
            retryCount = 0
            playChannel(it)
        }
    }

    fun setAutoQuality() {
        _selectedVideoTrackIndex.value = -1
        trackSelector.setParameters(
            trackSelector.buildUponParameters().clearOverridesOfType(C.TRACK_TYPE_VIDEO)
        )
    }

    fun selectVideoTrack(index: Int) {
        _selectedVideoTrackIndex.value = index
        val tracks = exoPlayer?.currentTracks ?: return

        for (trackGroup in tracks.groups) {
            if (trackGroup.type == C.TRACK_TYPE_VIDEO) {
                if (index in 0 until trackGroup.length) {
                    val override = TrackSelectionOverride(trackGroup.mediaTrackGroup, index)
                    trackSelector.setParameters(
                        trackSelector.buildUponParameters()
                            .setOverrideForType(override)
                    )
                }
                break
            }
        }
    }

    fun selectAudioTrack(index: Int) {
        _selectedAudioTrackIndex.value = index
        val tracks = exoPlayer?.currentTracks ?: return

        for (trackGroup in tracks.groups) {
            if (trackGroup.type == C.TRACK_TYPE_AUDIO) {
                if (index in 0 until trackGroup.length) {
                    val override = TrackSelectionOverride(trackGroup.mediaTrackGroup, index)
                    trackSelector.setParameters(
                        trackSelector.buildUponParameters()
                            .setOverrideForType(override)
                    )
                }
                break
            }
        }
    }

    private fun extractAvailableTracks(tracks: Tracks) {
        val videoList = mutableListOf<VideoTrackInfo>()
        val audioList = mutableListOf<AudioTrackInfo>()

        for (group in tracks.groups) {
            if (group.type == C.TRACK_TYPE_VIDEO) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val label = when {
                        format.height > 0 -> "${format.height}p"
                        format.bitrate > 0 -> "${format.bitrate / 1000} kbps"
                        else -> "Video Track ${i + 1}"
                    }
                    videoList.add(
                        VideoTrackInfo(
                            index = i,
                            label = label,
                            width = format.width,
                            height = format.height,
                            bitrate = format.bitrate
                        )
                    )
                }
            } else if (group.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val label = format.language?.uppercase()
                        ?: format.label
                        ?: "Audio ${i + 1}"
                    audioList.add(
                        AudioTrackInfo(
                            index = i,
                            label = label,
                            language = format.language
                        )
                    )
                }
            }
        }

        _availableVideoTracks.value = videoList
        _availableAudioTracks.value = audioList
    }

    fun stopAndRelease() {
        retryJob?.cancel()
        _currentChannel.value?.let { ch ->
            securityManager.releasePlayback(ch.id)
        }
        exoPlayer?.removeListener(playerListener)
        exoPlayer?.stop()
        exoPlayer?.release()
        exoPlayer = null
        _currentChannel.value = null
        _isPlaying.value = false
        _isBuffering.value = false
    }
}
