package com.example

import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LiveTvScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.splash.SplashScreen
import com.example.ui.theme.KbProTvTheme
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.NavDestination

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContent {
            val uiState by viewModel.uiState.collectAsState()

            KbProTvTheme(isOled = uiState.isOledMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    KbProTvApp(
                        viewModel = viewModel,
                        onBackPressed = {
                            when (uiState.currentDestination) {
                                NavDestination.LIVE_TV,
                                NavDestination.SEARCH,
                                NavDestination.SETTINGS -> viewModel.navigateTo(NavDestination.HOME)
                                else -> finish()
                            }
                        }
                    )
                }
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val currentState = viewModel.uiState.value
        if (currentState.currentDestination == NavDestination.LIVE_TV) {
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_UP,
                KeyEvent.KEYCODE_CHANNEL_UP,
                KeyEvent.KEYCODE_MEDIA_NEXT -> {
                    viewModel.nextChannel()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN,
                KeyEvent.KEYCODE_CHANNEL_DOWN,
                KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    viewModel.previousChannel()
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }
}

@Composable
fun KbProTvApp(
    viewModel: MainViewModel,
    onBackPressed: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    BackHandler {
        onBackPressed()
    }

    when (uiState.currentDestination) {
        NavDestination.SPLASH -> {
            SplashScreen(
                isLoading = uiState.isLoading,
                onFinish = { viewModel.navigateTo(NavDestination.HOME) }
            )
        }
        NavDestination.HOME -> {
            HomeScreen(
                uiState = uiState,
                onNavigate = { viewModel.navigateTo(it) },
                onCategorySelected = { viewModel.selectCategory(it) },
                onChannelSelected = { viewModel.playChannel(it) },
                onToggleFavorite = { viewModel.toggleFavorite(it) }
            )
        }
        NavDestination.LIVE_TV -> {
            LiveTvScreen(
                channel = uiState.activeChannel,
                resizeModeIndex = uiState.resizeModeIndex,
                currentTimeString = uiState.currentTimeString,
                onBack = { viewModel.navigateTo(NavDestination.HOME) },
                onNextChannel = { viewModel.nextChannel() },
                onPrevChannel = { viewModel.previousChannel() },
                onCycleAspectRatio = { viewModel.cycleAspectRatio() },
                onToggleFavorite = { viewModel.toggleFavorite(it) }
            )
        }
        NavDestination.SEARCH -> {
            SearchScreen(
                uiState = uiState,
                onBack = { viewModel.navigateTo(NavDestination.HOME) },
                onSearchQueryChanged = { viewModel.onSearchQueryChanged(it) },
                onChannelSelected = { viewModel.playChannel(it) },
                onToggleFavorite = { viewModel.toggleFavorite(it) }
            )
        }
        NavDestination.SETTINGS -> {
            SettingsScreen(
                uiState = uiState,
                onBack = { viewModel.navigateTo(NavDestination.HOME) },
                onToggleOled = { viewModel.toggleOledMode() },
                onRefreshPlaylist = { viewModel.loadChannels(forceRefresh = true) }
            )
        }
    }
}
