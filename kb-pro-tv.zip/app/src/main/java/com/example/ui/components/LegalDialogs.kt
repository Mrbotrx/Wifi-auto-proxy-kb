package com.example.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.KbCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun PrivacyPolicyDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Text(text = "Privacy Policy", color = TextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "KB PRO TV is committed to protecting your privacy. We do not collect, sell, or rent personal data to third parties. " +
                            "All preferences, favorites, and playlists are stored locally on your device in secure app storage.\n\n" +
                            "1. Information We Access: The application connects to authorized streaming playlist URLs to fetch channel metadata and streams. No personal identity or contacts are ever accessed.\n\n" +
                            "2. Local Cache: Streaming metadata is temporarily cached locally to optimize loading speeds and enable offline browsing of channels.\n\n" +
                            "3. Security: We implement modern security standards, encrypted sessions, and device binding to protect stream delivery.",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "Close", color = KbCyan)
            }
        }
    )
}

@Composable
fun TermsOfUseDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Text(text = "Terms of Use", color = TextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "By downloading and using KB PRO TV, you agree to these terms:\n\n" +
                            "1. Permitted Use: KB PRO TV is a media player interface designed to display publicly available live broadcast streams.\n\n" +
                            "2. Content Ownership: Content streams and trademarks belong entirely to their respective broadcast copyright owners.\n\n" +
                            "3. Anti-Abuse: Users may not extract, re-stream, reverse-engineer, or distribute stream tokens or backend mechanisms.\n\n" +
                            "4. Availability: Broadcast streams may change or become temporarily unavailable without prior notice based on origin servers.",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "Close", color = KbCyan)
            }
        }
    )
}

@Composable
fun OpenSourceLicensesDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Text(text = "Open Source Licenses", color = TextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "KB PRO TV is built using trusted open source components:\n\n" +
                            "• Android Jetpack & Compose (Apache 2.0 License)\n" +
                            "• AndroidX Media3 / ExoPlayer (Apache 2.0 License)\n" +
                            "• Coil Image Loading (Apache 2.0 License)\n" +
                            "• OkHttp (Apache 2.0 License)\n" +
                            "• Kotlin Coroutines (Apache 2.0 License)\n\n" +
                            "We thank the open source developer community for their contributions.",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "Close", color = KbCyan)
            }
        }
    )
}
