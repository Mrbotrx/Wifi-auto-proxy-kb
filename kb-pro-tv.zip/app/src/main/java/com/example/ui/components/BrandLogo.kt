package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.ui.theme.DarkSurfaceHigh

const val KB_LOGO_URL = "https://raw.githubusercontent.com/Mrbotrx/Mrbotrx/refs/heads/main/IPTV_LINKS_LOGO.jpg"

@Composable
fun BrandLogo(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    shape: RoundedCornerShape = RoundedCornerShape(8.dp)
) {
    val context = LocalContext.current
    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(DarkSurfaceHigh),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = ImageRequest.Builder(context)
                .data(KB_LOGO_URL)
                .crossfade(true)
                .build(),
            contentDescription = "KB PRO TV Logo",
            contentScale = ContentScale.Fit,
            error = painterResource(id = R.drawable.ic_channel_placeholder),
            fallback = painterResource(id = R.drawable.ic_channel_placeholder),
            placeholder = painterResource(id = R.drawable.ic_channel_placeholder),
            modifier = Modifier.fillMaxSize()
        )
    }
}
