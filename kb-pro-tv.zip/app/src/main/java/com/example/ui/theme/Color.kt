package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val KbCyan = Color(0xFF00E5FF)
val KbAccent = Color(0xFF00B0FF)
val KbBlue = Color(0xFF2979FF)
val KbLiveRed = Color(0xFFFF1744)
val KbGold = Color(0xFFFFD700)

val DarkBg = Color(0xFF0D0E12)
val DarkSurface = Color(0xFF161922)
val DarkSurfaceHigh = Color(0xFF1F2430)
val DarkSurfaceBorder = Color(0xFF2B3245)

val OledBg = Color(0xFF000000)
val OledSurface = Color(0xFF0A0A0A)
val OledSurfaceBorder = Color(0xFF1A1A1A)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB0B8C8)
val TextMuted = Color(0xFF6E7891)
