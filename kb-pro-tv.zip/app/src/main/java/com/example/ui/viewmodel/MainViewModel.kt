package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.category.CategoryClassifier
import com.example.data.model.Channel
import com.example.data.repository.LiveTvRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class NavDestination {
    SPLASH, HOME, LIVE_TV, SEARCH, SETTINGS
}

data class UiState(
    val isLoading: Boolean = true,
    val currentDestination: NavDestination = NavDestination.SPLASH,
    val channels: List<Channel> = emptyList(),
    val filteredChannels: List<Channel> = emptyList(),
    val selectedCategory: String = CategoryClassifier.CATEGORY_ALL,
    val searchQuery: String = "",
    val activeChannel: Channel? = null,
    val focusedChannel: Channel? = null,
    val isOledMode: Boolean = false,
    val currentTimeString: String = "",
    val errorMessage: String? = null,
    val isPlayerControlsVisible: Boolean = true,
    val resizeModeIndex: Int = 0 // 0: Fit, 1: Fill, 2: Zoom
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = LiveTvRepository(application)
    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    init {
        _uiState.update { it.copy(isOledMode = repository.appSettings.isOledMode) }
        startClockUpdates()
        loadChannels()
    }

    private fun startClockUpdates() {
        viewModelScope.launch {
            val format = SimpleDateFormat("hh:mm a", Locale.getDefault())
            while (isActive) {
                _uiState.update { it.copy(currentTimeString = format.format(Date())) }
                delay(10000)
            }
        }
    }

    fun loadChannels(forceRefresh: Boolean = false) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            val result = repository.getChannels(forceRefresh)
            result.onSuccess { channelList ->
                val lastId = repository.appSettings.lastChannelId
                val defaultChannel = channelList.find { it.id == lastId } ?: channelList.firstOrNull()
                _uiState.update { current ->
                    current.copy(
                        isLoading = false,
                        channels = channelList,
                        filteredChannels = filterChannels(channelList, current.selectedCategory, current.searchQuery),
                        activeChannel = defaultChannel,
                        focusedChannel = defaultChannel
                    )
                }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = "Failed to load channels: ${error.localizedMessage ?: "Unknown error"}"
                    )
                }
            }
        }
    }

    fun navigateTo(destination: NavDestination) {
        _uiState.update { it.copy(currentDestination = destination) }
    }

    fun selectCategory(category: String) {
        _uiState.update { current ->
            current.copy(
                selectedCategory = category,
                filteredChannels = filterChannels(current.channels, category, current.searchQuery)
            )
        }
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.update { current ->
            current.copy(
                searchQuery = query,
                filteredChannels = filterChannels(current.channels, current.selectedCategory, query)
            )
        }
    }

    fun playChannel(channel: Channel) {
        repository.appSettings.lastChannelId = channel.id
        _uiState.update {
            it.copy(
                activeChannel = channel,
                focusedChannel = channel,
                currentDestination = NavDestination.LIVE_TV
            )
        }
    }

    fun onChannelFocused(channel: Channel) {
        _uiState.update { it.copy(focusedChannel = channel) }
    }

    fun toggleFavorite(channelId: String) {
        val isFav = repository.appSettings.toggleFavorite(channelId)
        _uiState.update { current ->
            val updated = current.channels.map {
                if (it.id == channelId) it.copy(isFavorite = isFav) else it
            }
            current.copy(
                channels = updated,
                filteredChannels = filterChannels(updated, current.selectedCategory, current.searchQuery),
                activeChannel = if (current.activeChannel?.id == channelId) current.activeChannel.copy(isFavorite = isFav) else current.activeChannel
            )
        }
    }

    fun toggleOledMode() {
        val newMode = !_uiState.value.isOledMode
        repository.appSettings.isOledMode = newMode
        _uiState.update { it.copy(isOledMode = newMode) }
    }

    fun cycleAspectRatio() {
        _uiState.update { it.copy(resizeModeIndex = (it.resizeModeIndex + 1) % 3) }
    }

    fun setPlayerControlsVisible(visible: Boolean) {
        _uiState.update { it.copy(isPlayerControlsVisible = visible) }
    }

    fun nextChannel() {
        val list = _uiState.value.filteredChannels.takeIf { it.isNotEmpty() } ?: _uiState.value.channels
        if (list.isEmpty()) return
        val currentIdx = list.indexOfFirst { it.id == _uiState.value.activeChannel?.id }
        val nextIdx = (currentIdx + 1) % list.size
        playChannel(list[nextIdx])
    }

    fun previousChannel() {
        val list = _uiState.value.filteredChannels.takeIf { it.isNotEmpty() } ?: _uiState.value.channels
        if (list.isEmpty()) return
        val currentIdx = list.indexOfFirst { it.id == _uiState.value.activeChannel?.id }
        val prevIdx = if (currentIdx <= 0) list.size - 1 else currentIdx - 1
        playChannel(list[prevIdx])
    }

    private fun filterChannels(all: List<Channel>, category: String, query: String): List<Channel> {
        return all.filter { channel ->
            val matchesCategory = when (category) {
                CategoryClassifier.CATEGORY_ALL -> true
                "Favorites" -> channel.isFavorite
                else -> channel.category.equals(category, ignoreCase = true)
            }
            val matchesQuery = if (query.isBlank()) true else {
                channel.name.contains(query, ignoreCase = true) ||
                        channel.originalGroup.contains(query, ignoreCase = true) ||
                        channel.category.contains(query, ignoreCase = true)
            }
            matchesCategory && matchesQuery
        }
    }
}
