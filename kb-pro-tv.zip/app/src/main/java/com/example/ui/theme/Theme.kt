package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = KbCyan,
    secondary = KbAccent,
    tertiary = KbBlue,
    background = DarkBg,
    surface = DarkSurface,
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onTertiary = Color.White,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

private val OledColorScheme = darkColorScheme(
    primary = KbCyan,
    secondary = KbAccent,
    tertiary = KbBlue,
    background = OledBg,
    surface = OledSurface,
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onTertiary = Color.White,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun KbProTvTheme(
    isOled: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (isOled) OledColorScheme else DarkColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
