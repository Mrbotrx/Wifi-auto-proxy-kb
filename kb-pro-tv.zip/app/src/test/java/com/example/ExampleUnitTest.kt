package com.example

import com.example.data.category.CategoryClassifier
import com.example.data.parser.M3uParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testCategoryClassification() {
        val cat = CategoryClassifier.classify("BD News", "Somoy TV")
        assertEquals(CategoryClassifier.CATEGORY_BANGLA, cat)

        val sportCat = CategoryClassifier.classify("Sports", "T Sports HD")
        assertEquals(CategoryClassifier.CATEGORY_SPORTS, sportCat)
    }

    @Test
    fun testM3uParsing() {
        val sampleM3u = """
            #EXTM3U
            #EXTINF:-1 tvg-id="somoy" tvg-name="Somoy TV" tvg-logo="https://example.com/somoy.png" group-title="News",Somoy TV HD
            http://example.com/stream/somoy.m3u8
        """.trimIndent()

        val channels = M3uParser.parse(sampleM3u)
        assertEquals(1, channels.size)
        assertEquals("Somoy TV HD", channels[0].name)
        assertEquals("http://example.com/stream/somoy.m3u8", channels[0].streamUrl)
    }
}
