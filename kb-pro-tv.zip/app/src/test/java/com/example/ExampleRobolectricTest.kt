package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.category.CategoryClassifier
import com.example.data.parser.M3uParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("KB PRO TV", appName)
  }

  @Test
  fun `test M3U parser and category classification`() {
    val sampleM3u = """
      #EXTM3U
      #EXTINF:-1 tvg-id="bbc" tvg-name="BBC News HD" tvg-logo="https://example.com/bbc.png" group-title="News",BBC News HD
      https://example.com/bbc/live.m3u8
      #EXTINF:-1 tvg-id="sky_sports" tvg-name="Sky Sports Main" group-title="Sports",Sky Sports Main
      https://example.com/sky/live.m3u8
      #EXTINF:-1 tvg-id="somoy" tvg-name="Somoy TV" group-title="Bangla",Somoy TV
      https://example.com/somoy/live.m3u8
      #EXTINF:-1 tvg-id="jamuna" tvg-name="যমুনা টিভি" group-title="Bangla",যমুনা টিভি
      https://example.com/jamuna/live.m3u8
    """.trimIndent()

    val channels = M3uParser.parse(sampleM3u)
    assertEquals(4, channels.size)

    val bbc = channels.find { it.name == "BBC News HD" }
    assertNotNull(bbc)
    assertEquals(CategoryClassifier.CATEGORY_NEWS, bbc!!.category)

    val somoy = channels.find { it.name == "Somoy TV" }
    assertNotNull(somoy)
    assertEquals(CategoryClassifier.CATEGORY_BANGLA, somoy!!.category)

    val jamuna = channels.find { it.name == "যমুনা টিভি" }
    assertNotNull(jamuna)
    assertEquals(CategoryClassifier.CATEGORY_BANGLA, jamuna!!.category)
  }

  @Test
  fun `test religion category excluded`() {
    val sampleM3u = """
      #EXTM3U
      #EXTINF:-1 tvg-id="rel1" tvg-name="Islamic Channel" group-title="Religion",Islamic TV
      https://example.com/rel/live.m3u8
    """.trimIndent()

    val channels = M3uParser.parse(sampleM3u)
    assertEquals(1, channels.size)
    assertFalse(channels[0].category.equals("Religion", ignoreCase = true))
    assertEquals(CategoryClassifier.CATEGORY_OTHER, channels[0].category)
  }
}
